import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ExportOptions = ({ content, onExport, onPublishWordPress, extractedContent }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState('markdown');

  const exportFormats = [
    { 
      id: 'markdown', 
      label: 'Markdown', 
      extension: '.md',
      icon: 'FileText',
      description: 'Universal format for blogs and documentation'
    },
    { 
      id: 'html', 
      label: 'HTML', 
      extension: '.html',
      icon: 'Code',
      description: 'Web-ready formatted content'
    },
    { 
      id: 'docx', 
      label: 'Word Document', 
      extension: '.docx',
      icon: 'FileType',
      description: 'Microsoft Word compatible'
    },
    { 
      id: 'pdf', 
      label: 'PDF', 
      extension: '.pdf',
      icon: 'File',
      description: 'Printable document format'
    },
    { 
      id: 'txt', 
      label: 'Plain Text', 
      extension: '.txt',
      icon: 'FileText',
      description: 'Simple text format'
    },
    { 
      id: 'json', 
      label: 'JSON', 
      extension: '.json',
      icon: 'Braces',
      description: 'Structured data format'
    }
  ];

  const publishingPlatforms = [
    {
      id: 'wordpress',
      label: 'WordPress',
      icon: 'Globe',
      description: 'Publish directly to WordPress site',
      status: 'available'
    },
    {
      id: 'blogger',
      label: 'Blogger',
      icon: 'PenTool',
      description: 'Publish to Google Blogger',
      status: 'available'
    },
    {
      id: 'medium',
      label: 'Medium',
      icon: 'BookOpen',
      description: 'Publish to Medium platform',
      status: 'available'
    },
    {
      id: 'ghost',
      label: 'Ghost',
      icon: 'Feather',
      description: 'Publish to Ghost CMS',
      status: 'coming-soon'
    },
    {
      id: 'webflow',
      label: 'Webflow',
      icon: 'Layers',
      description: 'Publish to Webflow CMS',
      status: 'coming-soon'
    }
  ];

  const handleExport = async (format) => {
    setIsExporting(true);
    
    try {
      // Simulate export process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Create export data based on format
      let exportData;
      let mimeType;
      let filename;

      switch (format) {
        case 'markdown':
          exportData = generateMarkdown();
          mimeType = 'text/markdown';
          filename = `content-export-${Date.now()}.md`;
          break;
        case 'html':
          exportData = generateHTML();
          mimeType = 'text/html';
          filename = `content-export-${Date.now()}.html`;
          break;
        case 'json':
          exportData = JSON.stringify({
            source: extractedContent?.url,
            generated: new Date()?.toISOString(),
            content: content
          }, null, 2);
          mimeType = 'application/json';
          filename = `content-export-${Date.now()}.json`;
          break;
        case 'txt':
          exportData = generatePlainText();
          mimeType = 'text/plain';
          filename = `content-export-${Date.now()}.txt`;
          break;
        default:
          exportData = JSON.stringify(content, null, 2);
          mimeType = 'application/json';
          filename = `content-export-${Date.now()}.json`;
      }

      // Create and trigger download
      const blob = new Blob([exportData], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body?.appendChild(a);
      a?.click();
      document.body?.removeChild(a);
      URL.revokeObjectURL(url);

      onExport?.(format, exportData);
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const handlePublish = async (platform) => {
    setIsPublishing(true);
    
    try {
      // Simulate publishing process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Call the publishing function
      onPublishWordPress?.(content?.blog);
      
      // Show success message (in a real app, this would be handled by a toast/notification system)
      console.log(`Published to ${platform} successfully`);
    } catch (error) {
      console.error('Publishing failed:', error);
    } finally {
      setIsPublishing(false);
    }
  };

  const generateMarkdown = () => {
    const blog = content?.blog;
    if (!blog) return '';

    return `# ${blog?.title}

${blog?.metaDescription}

---

${blog?.content}

---

*Generated from: ${extractedContent?.url}*  
*Created on: ${new Date()?.toLocaleDateString()}*`;
  };

  const generateHTML = () => {
    const blog = content?.blog;
    if (!blog) return '';

    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${blog?.title}</title>
    <meta name="description" content="${blog?.metaDescription}">
</head>
<body>
    <article>
        <header>
            <h1>${blog?.title}</h1>
            <p><em>${blog?.metaDescription}</em></p>
        </header>
        
        <div class="content">
            ${blog?.content?.replace(/\n/g, '<br>')}
        </div>
        
        <footer>
            <p><small>Generated from: <a href="${extractedContent?.url}">${extractedContent?.url}</a></small></p>
            <p><small>Created on: ${new Date()?.toLocaleDateString()}</small></p>
        </footer>
    </article>
</body>
</html>`;
  };

  const generatePlainText = () => {
    const blog = content?.blog;
    if (!blog) return '';

    return `${blog?.title}

${blog?.metaDescription}

${blog?.content}

---
Generated from: ${extractedContent?.url}
Created on: ${new Date()?.toLocaleDateString()}`;
  };

  return (
    <div className="space-y-6">
      {/* Export Section */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Export Content</h3>
          <Icon name="Download" size={18} className="text-primary" />
        </div>

        <div className="space-y-4">
          {/* Format Selection */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Export Format
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {exportFormats?.map((format) => (
                <button
                  key={format?.id}
                  onClick={() => setSelectedFormat(format?.id)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    selectedFormat === format?.id
                      ? 'border-primary bg-primary/5' :'border-border hover:border-muted-foreground'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <Icon 
                      name={format?.icon} 
                      size={16} 
                      className={selectedFormat === format?.id ? 'text-primary' : 'text-muted-foreground'} 
                    />
                    <div className="flex-1">
                      <p className="font-medium text-foreground text-sm">{format?.label}</p>
                      <p className="text-xs text-muted-foreground">{format?.description}</p>
                    </div>
                    {selectedFormat === format?.id && (
                      <Icon name="Check" size={16} className="text-primary" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Export Button */}
          <Button
            onClick={() => handleExport(selectedFormat)}
            disabled={isExporting}
            className="w-full"
          >
            {isExporting ? (
              <>
                <Icon name="Loader2" size={16} className="animate-spin mr-2" />
                Exporting...
              </>
            ) : (
              <>
                <Icon name="Download" size={16} className="mr-2" />
                Download {exportFormats?.find(f => f?.id === selectedFormat)?.label}
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Publishing Section */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Direct Publishing</h3>
          <Icon name="Share" size={18} className="text-primary" />
        </div>

        <div className="space-y-3">
          {publishingPlatforms?.map((platform) => (
            <div
              key={platform?.id}
              className={`p-4 rounded-lg border transition-all ${
                platform?.status === 'available' ?'border-border hover:border-primary/50 bg-background' :'border-border bg-muted/20'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`p-2 rounded-md ${
                    platform?.status === 'available' ? 'bg-primary/10' : 'bg-muted'
                  }`}>
                    <Icon 
                      name={platform?.icon} 
                      size={16} 
                      className={platform?.status === 'available' ? 'text-primary' : 'text-muted-foreground'} 
                    />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{platform?.label}</p>
                    <p className="text-xs text-muted-foreground">{platform?.description}</p>
                  </div>
                </div>

                {platform?.status === 'available' ? (
                  <Button
                    size="sm"
                    onClick={() => handlePublish(platform?.id)}
                    disabled={isPublishing}
                    variant="outline"
                  >
                    {isPublishing ? (
                      <Icon name="Loader2" size={14} className="animate-spin" />
                    ) : (
                      <>
                        <Icon name="Send" size={14} className="mr-2" />
                        Publish
                      </>
                    )}
                  </Button>
                ) : (
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                    Coming Soon
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Publishing Note */}
        <div className="mt-4 p-3 bg-muted/50 rounded-lg">
          <div className="flex items-start space-x-2">
            <Icon name="Info" size={14} className="text-primary mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <p className="mb-1 font-medium">Publishing Requirements:</p>
              <ul className="space-y-1">
                <li>• Connect your accounts in Settings</li>
                <li>• Review content before publishing</li>
                <li>• Check platform-specific guidelines</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bulk Export Options */}
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">Bulk Export</h3>
          <Icon name="Package" size={18} className="text-primary" />
        </div>

        <div className="space-y-3">
          <Button
            variant="outline"
            onClick={() => handleExport('json')}
            className="w-full justify-start"
          >
            <Icon name="Archive" size={16} className="mr-3" />
            <div className="text-left">
              <p className="font-medium">Export All Formats</p>
              <p className="text-xs text-muted-foreground">Download ZIP with all formats</p>
            </div>
          </Button>

          <Button
            variant="outline"
            onClick={() => handleExport('json')}
            className="w-full justify-start"
          >
            <Icon name="Share2" size={16} className="mr-3" />
            <div className="text-left">
              <p className="font-medium">Social Media Pack</p>
              <p className="text-xs text-muted-foreground">All social media variations</p>
            </div>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ExportOptions;