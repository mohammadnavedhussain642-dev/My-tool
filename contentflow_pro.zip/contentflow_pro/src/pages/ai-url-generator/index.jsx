import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import UrlInput from './components/UrlInput';
import ContentExtractor from './components/ContentExtractor';
import ContentPreview from './components/ContentPreview';
import GenerationOptions from './components/GenerationOptions';
import BatchProcessor from './components/BatchProcessor';
import ExportOptions from './components/ExportOptions';

const AiUrlGenerator = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Core state management
  const [activeTab, setActiveTab] = useState('single'); // single, batch
  const [urlInput, setUrlInput] = useState('');
  const [batchUrls, setBatchUrls] = useState([]);
  const [extractedContent, setExtractedContent] = useState(null);
  const [generatedContent, setGeneratedContent] = useState(null);
  const [isExtracting, setIsExtracting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [extractionProgress, setExtractionProgress] = useState(0);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [errors, setErrors] = useState({});
  
  // Generation options
  const [selectedContentTypes, setSelectedContentTypes] = useState(['blog']);
  const [selectedPlatforms, setSelectedPlatforms] = useState(['wordpress']);
  const [seoOptimization, setSeoOptimization] = useState(true);
  const [contentTone, setContentTone] = useState('professional');
  const [contentLength, setContentLength] = useState('medium');

  useEffect(() => {
    // Cleanup on unmount
    return () => {
      setIsExtracting(false);
      setIsGenerating(false);
    };
  }, []);

  const validateUrl = useCallback((url) => {
    const urlPattern = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
    return urlPattern?.test(url);
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const extractContent = async (url) => {
    if (!validateUrl(url)) {
      setErrors({ url: 'Please enter a valid URL' });
      return;
    }

    setIsExtracting(true);
    setExtractionProgress(0);
    setErrors({});

    try {
      // Simulate content extraction process
      const progressInterval = setInterval(() => {
        setExtractionProgress(prev => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            return 100;
          }
          return prev + 20;
        });
      }, 500);

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2500));

      // Mock extracted content
      const mockContent = {
        url,
        title: 'How to Build Scalable SaaS Applications in 2025',
        description: 'Learn the essential strategies and technologies for building scalable SaaS applications that can handle millions of users.',
        content: 'Building scalable SaaS applications requires careful planning, robust architecture, and the right technology stack. In this comprehensive guide, we\'ll explore the key principles of SaaS scalability, from database design to microservices architecture...',
        images: [
          'https://example.com/image1.jpg',
          'https://example.com/image2.jpg'
        ],
        metadata: {
          wordCount: 2500,
          readingTime: '12 min',
          publishDate: '2025-01-15',
          author: 'Tech Expert',
          tags: ['SaaS', 'Scalability', 'Architecture', 'Technology']
        },
        keywords: ['SaaS', 'scalability', 'architecture', 'microservices', 'database'],
        headings: [
          'Introduction to SaaS Scalability',
          'Database Architecture Considerations',
          'Microservices vs Monolithic Architecture',
          'Performance Optimization Strategies'
        ]
      };

      setExtractedContent(mockContent);
      clearInterval(progressInterval);
      setExtractionProgress(100);
    } catch (error) {
      setErrors({ extraction: 'Failed to extract content from URL. Please try again.' });
      console.error('Content extraction error:', error);
    } finally {
      setIsExtracting(false);
    }
  };

  const generateContent = async () => {
    if (!extractedContent) {
      setErrors({ generation: 'Please extract content first' });
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);
    setErrors({});

    try {
      // Simulate content generation process
      const progressInterval = setInterval(() => {
        setGenerationProgress(prev => {
          if (prev >= 100) {
            clearInterval(progressInterval);
            return 100;
          }
          return prev + 15;
        });
      }, 400);

      // Simulate API processing time
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Mock generated content for different formats
      const mockGenerated = {
        blog: {
          title: 'The Ultimate Guide to Building Scalable SaaS Applications in 2025',
          content: '# The Ultimate Guide to Building Scalable SaaS Applications in 2025\n\nBuilding a successful SaaS application is more than just writing code – it\'s about creating a system that can grow with your business...',
          metaDescription: 'Discover the essential strategies for building scalable SaaS applications in 2025. Learn about architecture, performance optimization, and best practices.',
          wordCount: 1500,
          seoScore: 85,
          estimatedReadingTime: '8 min'
        },
        social: {
          twitter: '🚀 Want to build a SaaS that scales to millions of users? Here\'s what you need to know about scalable architecture in 2025:\n\n✅ Database sharding\n✅ Microservices\n✅ Caching strategies\n✅ Load balancing\n\n#SaaS #TechTips',
          linkedin: 'Building scalable SaaS applications is crucial for long-term success. Key considerations include:\n\n• Database architecture and sharding\n• Microservices vs monolithic design\n• Performance optimization strategies\n• Infrastructure planning\n\nWhat\'s your biggest scaling challenge?',
          instagram: '💡 SaaS Scaling Tips for 2025:\n\n🔹 Plan your database architecture early\n🔹 Consider microservices for complex apps\n🔹 Implement proper caching\n🔹 Monitor performance metrics\n\n#SaaS #TechTips #Scaling'
        },
        email: {
          subject: '5 Proven Strategies for Scaling Your SaaS Application',
          preview: 'Essential architectural decisions that will make or break your SaaS growth',
          content: 'Hi there,\n\nScaling a SaaS application is one of the biggest challenges founders face...'
        }
      };

      setGeneratedContent(mockGenerated);
      clearInterval(progressInterval);
      setGenerationProgress(100);
    } catch (error) {
      setErrors({ generation: 'Failed to generate content. Please try again.' });
      console.error('Content generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleBatchProcessing = async (urls) => {
    setBatchUrls(urls);
    // Process multiple URLs sequentially or in parallel
    for (const url of urls) {
      await extractContent(url);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Delay between requests
    }
  };

  const handleExportContent = (format, content) => {
    const exportData = {
      format,
      content,
      timestamp: new Date()?.toISOString(),
      source: extractedContent?.url
    };

    // Create and trigger download
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `content-export-${format}-${Date.now()}.json`;
    document.body?.appendChild(a);
    a?.click();
    document.body?.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePublishToWordPress = async (content) => {
    // Mock WordPress publishing
    console.log('Publishing to WordPress:', content);
    // Implementation would integrate with WordPress API
  };

  const handleNavigateToEditor = () => {
    if (generatedContent) {
      navigate('/content-editor', { 
        state: { 
          importedContent: generatedContent,
          sourceUrl: extractedContent?.url 
        } 
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />
      </div>

      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-72'
      }`}>
        <div className="p-6 max-w-7xl mx-auto">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  AI URL Generator
                </h1>
                <p className="text-muted-foreground">
                  Extract content from any website and transform it into SEO-optimized posts across multiple platforms
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 px-3 py-2 bg-primary/10 rounded-lg">
                  <Icon name="Zap" size={16} className="text-primary" />
                  <span className="text-sm font-medium text-primary">AI Powered</span>
                </div>
              </div>
            </div>

            {/* Tab Navigation */}
            <div className="flex space-x-1 bg-muted rounded-lg p-1 w-fit">
              <button
                onClick={() => setActiveTab('single')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'single' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Single URL
              </button>
              <button
                onClick={() => setActiveTab('batch')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  activeTab === 'batch' ?'bg-background text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Batch Processing
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            {/* Main Content Area */}
            <div className="xl:col-span-8 space-y-6">
              {/* URL Input Section */}
              {activeTab === 'single' ? (
                <UrlInput
                  value={urlInput}
                  onChange={setUrlInput}
                  onExtract={() => extractContent(urlInput)}
                  isExtracting={isExtracting}
                  progress={extractionProgress}
                  error={errors?.url}
                  placeholder="Enter website URL (e.g., https://example.com/blog-post)"
                />
              ) : (
                <BatchProcessor
                  urls={batchUrls}
                  onProcess={handleBatchProcessing}
                  isProcessing={isExtracting}
                />
              )}

              {/* Content Extraction Results */}
              {extractedContent && (
                <ContentExtractor
                  content={extractedContent}
                  isExtracting={isExtracting}
                  progress={extractionProgress}
                />
              )}

              {/* Generation Options */}
              {extractedContent && !isExtracting && (
                <GenerationOptions
                  selectedTypes={selectedContentTypes}
                  onTypesChange={setSelectedContentTypes}
                  selectedPlatforms={selectedPlatforms}
                  onPlatformsChange={setSelectedPlatforms}
                  seoEnabled={seoOptimization}
                  onSeoChange={setSeoOptimization}
                  tone={contentTone}
                  onToneChange={setContentTone}
                  length={contentLength}
                  onLengthChange={setContentLength}
                  onGenerate={generateContent}
                  isGenerating={isGenerating}
                  progress={generationProgress}
                  error={errors?.generation}
                />
              )}

              {/* Generated Content Preview */}
              {generatedContent && (
                <ContentPreview
                  content={generatedContent}
                  selectedTypes={selectedContentTypes}
                  onNavigateToEditor={handleNavigateToEditor}
                />
              )}
            </div>

            {/* Sidebar */}
            <div className="xl:col-span-4 space-y-6">
              {/* Real-time Status */}
              <div className="bg-card rounded-lg border border-border p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-foreground">Processing Status</h3>
                  <div className={`w-2 h-2 rounded-full ${
                    isExtracting || isGenerating ? 'bg-warning animate-pulse' : 'bg-success'
                  }`}></div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Content Extraction</span>
                      <span className="text-foreground">{extractionProgress}%</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${extractionProgress}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Content Generation</span>
                      <span className="text-foreground">{generationProgress}%</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-success h-2 rounded-full transition-all duration-300"
                        style={{ width: `${generationProgress}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                {(isExtracting || isGenerating) && (
                  <div className="mt-4 flex items-center space-x-2 text-sm text-muted-foreground">
                    <Icon name="Clock" size={14} />
                    <span>
                      Estimated time: {isExtracting ? '30s' : '45s'} remaining
                    </span>
                  </div>
                )}
              </div>

              {/* Export Options */}
              {generatedContent && (
                <ExportOptions
                  content={generatedContent}
                  onExport={handleExportContent}
                  onPublishWordPress={handlePublishToWordPress}
                  extractedContent={extractedContent}
                />
              )}

              {/* Usage Statistics */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4">Today's Usage</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">URLs Processed</span>
                    <span className="text-foreground font-medium">12/50</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Content Generated</span>
                    <span className="text-foreground font-medium">8 posts</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Export Downloads</span>
                    <span className="text-foreground font-medium">5</span>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-border">
                  <button 
                    onClick={() => navigate('/pricing-plans')}
                    className="w-full text-sm text-primary hover:text-primary/80 transition-colors"
                  >
                    Upgrade for unlimited processing →
                  </button>
                </div>
              </div>

              {/* Quick Tips */}
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4">Pro Tips</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start space-x-2">
                    <Icon name="Lightbulb" size={14} className="text-warning mt-0.5" />
                    <span className="text-muted-foreground">
                      Use specific article URLs for best content extraction results
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Target" size={14} className="text-success mt-0.5" />
                    <span className="text-muted-foreground">
                      Enable SEO optimization for better search rankings
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Icon name="Zap" size={14} className="text-primary mt-0.5" />
                    <span className="text-muted-foreground">
                      Batch process multiple URLs to save time
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AiUrlGenerator;