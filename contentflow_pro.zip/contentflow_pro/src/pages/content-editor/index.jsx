import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import EditorToolbar from './components/EditorToolbar';
import PlatformTabs from './components/PlatformTabs';
import PlatformPanel from './components/PlatformPanel';
import ContentEditor from './components/ContentEditor';
import ContentTemplates from './components/ContentTemplates';
import ExportOptions from './components/ExportOptions';

import Button from '../../components/ui/Button';

const ContentEditorPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Layout state
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showPlatformPanel, setShowPlatformPanel] = useState(true);
  
  // Content state
  const [content, setContent] = useState('');
  const [activePlatform, setActivePlatform] = useState('blog');
  const [activeFormats, setActiveFormats] = useState([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Modal state
  const [showTemplates, setShowTemplates] = useState(false);
  const [showExportOptions, setShowExportOptions] = useState(false);

  // Mock data for platforms
  const platforms = [
    {
      id: 'blog',
      name: 'Blog Post',
      icon: 'FileText',
      description: 'Long-form content with rich formatting'
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: 'Instagram',
      description: 'Visual content with engaging captions'
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      icon: 'Linkedin',
      description: 'Professional networking content'
    },
    {
      id: 'twitter',
      name: 'Twitter',
      icon: 'Twitter',
      description: 'Short-form microblogging content'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: 'Facebook',
      description: 'Social media posts for engagement'
    },
    {
      id: 'reddit',
      name: 'Reddit',
      icon: 'MessageCircle',
      description: 'Community-focused discussions'
    },
    {
      id: 'discord',
      name: 'Discord',
      icon: 'MessageSquare',
      description: 'Community server content'
    },
    {
      id: 'quora',
      name: 'Quora',
      icon: 'HelpCircle',
      description: 'Question and answer format'
    },
    {
      id: 'threads',
      name: 'Threads',
      icon: 'AtSign',
      description: 'Meta\'s text-based social platform'
    }
  ];

  // Initialize content from location state or mock data
  useEffect(() => {
    const initialContent = location?.state?.content || `# Welcome to ContentFlow Pro Editor

This is your AI-generated content ready for editing and refinement. You can:

• Edit and format your content using the toolbar above
• Switch between different platform formats using the tabs
• Preview how your content will look on each platform
• Export to multiple formats or publish directly

## Getting Started

1. **Edit Your Content**: Use the rich text editor to refine your AI-generated content
2. **Choose Platform**: Select the target platform from the tabs above
3. **Preview & Optimize**: See how your content looks and get platform-specific suggestions
4. **Publish or Export**: Share directly to platforms or download in various formats

## Sample Content

Here's some sample content to demonstrate the editor capabilities:

**Key Benefits:**
- Streamlined content creation workflow
- Multi-platform optimization
- AI-powered suggestions and improvements
- Real-time collaboration features

**Call to Action:**
Ready to transform your content creation process? Start editing now and see the difference!

---

*This content was generated on ${new Date()?.toLocaleDateString()} using ContentFlow Pro's AI engine.*`;

    setContent(initialContent);
  }, [location?.state]);

  // Handle content changes
  const handleContentChange = (newContent) => {
    setContent(newContent);
    // In a real app, this would update undo/redo state
    setCanUndo(true);
  };

  // Handle formatting
  const handleFormat = (formatType) => {
    console.log(`Applying format: ${formatType}`);
    // In a real app, this would apply text formatting
    setActiveFormats(prev => 
      prev?.includes(formatType) 
        ? prev?.filter(f => f !== formatType)
        : [...prev, formatType]
    );
  };

  // Handle save
  const handleSave = async () => {
    setIsSaving(true);
    // Simulate save operation
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    console.log('Content saved successfully');
  };

  // Handle undo/redo
  const handleUndo = () => {
    console.log('Undo action');
    setCanRedo(true);
  };

  const handleRedo = () => {
    console.log('Redo action');
    setCanUndo(true);
  };

  // Handle platform change
  const handlePlatformChange = (platformId) => {
    setActivePlatform(platformId);
  };

  // Handle template selection
  const handleTemplateSelect = (templateContent) => {
    setContent(templateContent);
  };

  // Handle navigation
  const handleNavigation = (path) => {
    navigate(path);
  };

  // Get current platform data
  const currentPlatform = platforms?.find(p => p?.id === activePlatform) || platforms?.[0];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        isMenuOpen={isMobileMenuOpen}
      />

      {/* Main Layout */}
      <div className="flex pt-16">
        {/* Sidebar */}
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />

        {/* Main Content */}
        <main className={`flex-1 transition-all duration-300 ${
          isSidebarCollapsed ? 'ml-16' : 'ml-72'
        }`}>
          <div className="h-[calc(100vh-4rem)] flex flex-col">
            {/* Top Action Bar */}
            <div className="flex items-center justify-between p-4 bg-card border-b border-border">
              <div className="flex items-center space-x-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate('/content-upload')}
                  iconName="ArrowLeft"
                  iconPosition="left"
                >
                  Back to Upload
                </Button>
                
                <div className="w-px h-6 bg-border"></div>
                
                <h1 className="text-xl font-semibold text-foreground">Content Editor</h1>
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowTemplates(true)}
                  iconName="Layout"
                  iconPosition="left"
                >
                  Templates
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowExportOptions(true)}
                  iconName="Download"
                  iconPosition="left"
                >
                  Export
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPlatformPanel(!showPlatformPanel)}
                  iconName={showPlatformPanel ? "PanelRightClose" : "PanelRightOpen"}
                  iconPosition="left"
                >
                  {showPlatformPanel ? 'Hide' : 'Show'} Panel
                </Button>
                
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => navigate('/content-scheduler')}
                  iconName="Calendar"
                  iconPosition="left"
                >
                  Schedule
                </Button>
              </div>
            </div>

            {/* Platform Tabs */}
            <div className="p-4 bg-card border-b border-border">
              <PlatformTabs
                activePlatform={activePlatform}
                onPlatformChange={handlePlatformChange}
                platforms={platforms}
              />
            </div>

            {/* Editor Layout */}
            <div className="flex-1 flex min-h-0">
              {/* Editor Section */}
              <div className={`flex-1 flex flex-col transition-all duration-300 ${
                showPlatformPanel ? 'mr-80' : ''
              }`}>
                {/* Editor Toolbar */}
                <EditorToolbar
                  onFormat={handleFormat}
                  activeFormats={activeFormats}
                  onUndo={handleUndo}
                  onRedo={handleRedo}
                  canUndo={canUndo}
                  canRedo={canRedo}
                  onSave={handleSave}
                  isSaving={isSaving}
                />

                {/* Content Editor */}
                <div className="flex-1">
                  <ContentEditor
                    content={content}
                    onContentChange={handleContentChange}
                    placeholder="Start writing your content..."
                  />
                </div>
              </div>

              {/* Platform Panel */}
              {showPlatformPanel && (
                <div className="fixed right-0 top-16 bottom-0 w-80 z-30">
                  <PlatformPanel
                    platform={currentPlatform}
                    content={content}
                    onContentChange={handleContentChange}
                  />
                </div>
              )}
            </div>
          </div>
        </main>
      </div>

      {/* Modals */}
      <ContentTemplates
        isVisible={showTemplates}
        onClose={() => setShowTemplates(false)}
        onTemplateSelect={handleTemplateSelect}
      />

      <ExportOptions
        content={content}
        isVisible={showExportOptions}
        onClose={() => setShowExportOptions(false)}
      />

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

export default ContentEditorPage;