import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const AnalyticsPanel = ({ isVisible, onToggle }) => {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock analytics data
  const overviewStats = [
    { label: 'Total Content', value: '247', change: '+12%', trend: 'up' },
    { label: 'Published', value: '189', change: '+8%', trend: 'up' },
    { label: 'Total Views', value: '45.2K', change: '+23%', trend: 'up' },
    { label: 'Engagement Rate', value: '4.8%', change: '+0.3%', trend: 'up' }
  ];

  const contentByPlatform = [
    { name: 'Instagram', value: 45, color: '#E1306C' },
    { name: 'LinkedIn', value: 32, color: '#0077B5' },
    { name: 'Twitter', value: 28, color: '#1DA1F2' },
    { name: 'Blog', value: 25, color: '#FF6B35' },
    { name: 'YouTube', value: 18, color: '#FF0000' }
  ];

  const performanceData = [
    { month: 'Jan', views: 2400, engagement: 240 },
    { month: 'Feb', views: 3200, engagement: 320 },
    { month: 'Mar', views: 2800, engagement: 280 },
    { month: 'Apr', views: 4100, engagement: 410 },
    { month: 'May', views: 3800, engagement: 380 },
    { month: 'Jun', views: 4500, engagement: 450 }
  ];

  const storageInfo = {
    used: 2.4,
    total: 10,
    percentage: 24
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'BarChart3' },
    { id: 'performance', label: 'Performance', icon: 'TrendingUp' },
    { id: 'storage', label: 'Storage', icon: 'HardDrive' }
  ];

  if (!isVisible) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={onToggle}
        iconName="BarChart3"
        className="fixed bottom-6 right-6 z-30 shadow-moderate"
      >
        Analytics
      </Button>
    );
  }

  return (
    <div className="fixed right-0 top-16 bottom-0 w-80 bg-card border-l border-border z-30 overflow-y-auto">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Analytics</h3>
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggle}
            iconName="X"
          />
        </div>

        {/* Tabs */}
        <div className="flex space-x-1 bg-muted rounded-lg p-1">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveTab(tab?.id)}
              className={`flex-1 flex items-center justify-center space-x-1 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                activeTab === tab?.id
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Icon name={tab?.icon} size={14} />
              <span>{tab?.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="p-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              {overviewStats?.map((stat, index) => (
                <div key={index} className="bg-muted rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">{stat?.label}</span>
                    <Icon 
                      name={stat?.trend === 'up' ? 'TrendingUp' : 'TrendingDown'} 
                      size={12} 
                      className={stat?.trend === 'up' ? 'text-success' : 'text-destructive'}
                    />
                  </div>
                  <div className="text-lg font-semibold text-foreground">{stat?.value}</div>
                  <div className={`text-xs ${stat?.trend === 'up' ? 'text-success' : 'text-destructive'}`}>
                    {stat?.change}
                  </div>
                </div>
              ))}
            </div>

            {/* Content Distribution */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3">Content by Platform</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={contentByPlatform}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={70}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {contentByPlatform?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry?.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-2 mt-3">
                {contentByPlatform?.map((platform, index) => (
                  <div key={index} className="flex items-center justify-between text-xs">
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: platform?.color }}
                      ></div>
                      <span className="text-muted-foreground">{platform?.name}</span>
                    </div>
                    <span className="font-medium text-foreground">{platform?.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'performance' && (
          <div className="space-y-6">
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3">Monthly Performance</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fontSize: 12, fill: 'var(--color-muted-foreground)' }}
                    />
                    <YAxis 
                      tick={{ fontSize: 12, fill: 'var(--color-muted-foreground)' }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'var(--color-popover)',
                        border: '1px solid var(--color-border)',
                        borderRadius: '6px'
                      }}
                    />
                    <Bar dataKey="views" fill="var(--color-primary)" radius={[2, 2, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Top Performing Content */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3">Top Performing</h4>
              <div className="space-y-3">
                {[
                  { title: "10 Tips for Better Content Creation", views: "12.5K", platform: "LinkedIn" },
                  { title: "Social Media Strategy Guide", views: "8.9K", platform: "Instagram" },
                  { title: "Content Marketing Trends 2024", views: "7.2K", platform: "Blog" }
                ]?.map((content, index) => (
                  <div key={index} className="flex items-center space-x-3 p-2 bg-muted rounded-lg">
                    <div className="w-8 h-8 bg-primary/10 rounded flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">#{index + 1}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{content?.title}</p>
                      <p className="text-xs text-muted-foreground">{content?.platform} • {content?.views} views</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'storage' && (
          <div className="space-y-6">
            {/* Storage Usage */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-foreground">Storage Usage</h4>
                <span className="text-xs text-muted-foreground">
                  {storageInfo?.used}GB / {storageInfo?.total}GB
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${storageInfo?.percentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                {storageInfo?.total - storageInfo?.used}GB remaining
              </p>
            </div>

            {/* Storage Breakdown */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-3">Storage Breakdown</h4>
              <div className="space-y-3">
                {[
                  { type: 'Videos', size: '1.2GB', percentage: 50, color: 'bg-blue-500' },
                  { type: 'Audio', size: '0.8GB', percentage: 33, color: 'bg-green-500' },
                  { type: 'Images', size: '0.3GB', percentage: 13, color: 'bg-yellow-500' },
                  { type: 'Documents', size: '0.1GB', percentage: 4, color: 'bg-purple-500' }
                ]?.map((item, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">{item?.type}</span>
                      <span className="font-medium text-foreground">{item?.size}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-1">
                      <div 
                        className={`${item?.color} h-1 rounded-full transition-all duration-300`}
                        style={{ width: `${item?.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upgrade Prompt */}
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-3">
              <div className="flex items-start space-x-2">
                <Icon name="Zap" size={16} className="text-primary mt-0.5" />
                <div className="flex-1">
                  <h5 className="text-sm font-medium text-foreground mb-1">Need More Space?</h5>
                  <p className="text-xs text-muted-foreground mb-2">
                    Upgrade to Pro for 100GB storage and unlimited content generation.
                  </p>
                  <Button variant="default" size="sm" className="w-full">
                    Upgrade Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalyticsPanel;