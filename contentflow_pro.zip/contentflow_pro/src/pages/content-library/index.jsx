import React, { useState, useEffect } from 'react';

import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';

import FilterPanel from './components/FilterPanel';
import BulkActions from './components/BulkActions';
import AnalyticsPanel from './components/AnalyticsPanel';
import ContentGrid from './components/ContentGrid';

const ContentLibrary = () => {
  const [content, setContent] = useState([]);
  const [filteredContent, setFilteredContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedItems, setSelectedItems] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [viewMode, setViewMode] = useState('grid');
  const [filters, setFilters] = useState({
    search: '',
    contentType: 'all',
    platform: 'all',
    status: 'all',
    dateRange: { start: '', end: '' },
    sortBy: 'newest',
    showFavorites: false
  });

  // Mock content data
  const mockContent = [
    {
      id: 1,
      title: "10 Essential Tips for Content Creation Success",
      thumbnail: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=300&fit=crop",
      sourceType: "video",
      platforms: ["Instagram", "LinkedIn", "Twitter"],
      createdAt: "2025-01-15T10:30:00Z",
      status: "published",
      duration: "3:45",
      metrics: {
        views: 12500,
        likes: 890,
        comments: 156
      },
      tags: ["tips", "content creation", "social media"]
    },
    {
      id: 2,
      title: "Social Media Strategy Deep Dive Podcast Episode",
      thumbnail: "https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=400&h=300&fit=crop",
      sourceType: "audio",
      platforms: ["Blog", "LinkedIn"],
      createdAt: "2025-01-12T14:20:00Z",
      status: "scheduled",
      duration: "45:20",
      metrics: {
        views: 8900,
        likes: 234,
        comments: 67
      },
      tags: ["strategy", "podcast", "marketing"]
    },
    {
      id: 3,
      title: "Quick Tutorial: Video Editing Basics",
      thumbnail: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=300&fit=crop",
      sourceType: "video",
      platforms: ["YouTube", "Instagram", "Facebook"],
      createdAt: "2025-01-10T09:15:00Z",
      status: "published",
      duration: "8:12",
      metrics: {
        views: 25600,
        likes: 1200,
        comments: 89
      },
      tags: ["tutorial", "video editing", "beginner"]
    },
    {
      id: 4,
      title: "Content Marketing Trends for 2025",
      thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      sourceType: "text",
      platforms: ["Blog", "LinkedIn", "Thread"],
      createdAt: "2025-01-08T16:45:00Z",
      status: "draft",
      duration: "5 min read",
      tags: ["trends", "marketing", "2025"]
    },
    {
      id: 5,
      title: "Behind the Scenes: Content Creation Process",
      thumbnail: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=400&h=300&fit=crop",
      sourceType: "video",
      platforms: ["Instagram", "YouTube"],
      createdAt: "2025-01-05T11:30:00Z",
      status: "published",
      duration: "12:34",
      metrics: {
        views: 18700,
        likes: 945,
        comments: 203
      },
      tags: ["behind the scenes", "process", "vlog"]
    },
    {
      id: 6,
      title: "Productivity Hacks for Content Creators",
      thumbnail: "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=400&h=300&fit=crop",
      sourceType: "audio",
      platforms: ["LinkedIn", "Twitter", "Blog"],
      createdAt: "2025-01-03T13:20:00Z",
      status: "published",
      duration: "28:15",
      metrics: {
        views: 7200,
        likes: 456,
        comments: 78
      },
      tags: ["productivity", "hacks", "creators"]
    }
  ];

  const viewModeOptions = [
    { value: 'grid', label: 'Grid View' },
    { value: 'list', label: 'List View' }
  ];

  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      setContent(mockContent);
      setFilteredContent(mockContent);
      setLoading(false);
    }, 1000);
  }, []);

  useEffect(() => {
    // Apply filters
    let filtered = [...content];

    // Search filter
    if (filters?.search) {
      filtered = filtered?.filter(item =>
        item?.title?.toLowerCase()?.includes(filters?.search?.toLowerCase()) ||
        item?.tags?.some(tag => tag?.toLowerCase()?.includes(filters?.search?.toLowerCase()))
      );
    }

    // Content type filter
    if (filters?.contentType !== 'all') {
      filtered = filtered?.filter(item => item?.sourceType === filters?.contentType);
    }

    // Platform filter
    if (filters?.platform !== 'all') {
      filtered = filtered?.filter(item => item?.platforms?.includes(filters?.platform));
    }

    // Status filter
    if (filters?.status !== 'all') {
      filtered = filtered?.filter(item => item?.status === filters?.status);
    }

    // Date range filter
    if (filters?.dateRange?.start && filters?.dateRange?.end) {
      const startDate = new Date(filters.dateRange.start);
      const endDate = new Date(filters.dateRange.end);
      filtered = filtered?.filter(item => {
        const itemDate = new Date(item.createdAt);
        return itemDate >= startDate && itemDate <= endDate;
      });
    }

    // Sort
    filtered?.sort((a, b) => {
      switch (filters?.sortBy) {
        case 'newest':
          return new Date(b.createdAt) - new Date(a.createdAt);
        case 'oldest':
          return new Date(a.createdAt) - new Date(b.createdAt);
        case 'title':
          return a?.title?.localeCompare(b?.title);
        case 'views':
          return (b?.metrics?.views || 0) - (a?.metrics?.views || 0);
        case 'likes':
          return (b?.metrics?.likes || 0) - (a?.metrics?.likes || 0);
        default:
          return 0;
      }
    });

    setFilteredContent(filtered);
  }, [content, filters]);

  const handleSelectItem = (itemId) => {
    setSelectedItems(prev =>
      prev?.includes(itemId)
        ? prev?.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleSelectAll = () => {
    if (selectedItems?.length === filteredContent?.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(filteredContent?.map(item => item?.id));
    }
  };

  const handleEdit = (contentItem) => {
    console.log('Edit content:', contentItem);
    window.location.href = `/content-editor?id=${contentItem?.id}`;
  };

  const handleDuplicate = (contentItem) => {
    console.log('Duplicate content:', contentItem);
    const duplicated = {
      ...contentItem,
      id: Date.now(),
      title: `${contentItem?.title} (Copy)`,
      status: 'draft',
      createdAt: new Date()?.toISOString()
    };
    setContent(prev => [duplicated, ...prev]);
  };

  const handleSchedule = (contentItem) => {
    console.log('Schedule content:', contentItem);
    window.location.href = `/content-scheduler?content=${contentItem?.id}`;
  };

  const handleDelete = (contentItem) => {
    if (window.confirm('Are you sure you want to delete this content?')) {
      setContent(prev => prev?.filter(item => item?.id !== contentItem?.id));
      setSelectedItems(prev => prev?.filter(id => id !== contentItem?.id));
    }
  };

  const handleBulkEdit = (items) => {
    console.log('Bulk edit:', items);
    window.location.href = `/content-editor?bulk=${items?.join(',')}`;
  };

  const handleBulkSchedule = (items, when = null) => {
    console.log('Bulk schedule:', items, when);
    if (when === 'tomorrow') {
      // Quick schedule for tomorrow
      alert(`Scheduled ${items?.length} items for tomorrow`);
    } else {
      window.location.href = `/content-scheduler?bulk=${items?.join(',')}`;
    }
  };

  const handleBulkDelete = (items) => {
    if (window.confirm(`Are you sure you want to delete ${items?.length} items?`)) {
      setContent(prev => prev?.filter(item => !items?.includes(item?.id)));
      setSelectedItems([]);
    }
  };

  const handleBulkExport = (items, format) => {
    console.log('Bulk export:', items, format);
    alert(`Exporting ${items?.length} items as ${format?.toUpperCase()}`);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      contentType: 'all',
      platform: 'all',
      status: 'all',
      dateRange: { start: '', end: '' },
      sortBy: 'newest',
      showFavorites: false
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border sticky top-16 z-20">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Content Library</h1>
              <p className="text-muted-foreground">
                Manage and organize all your generated content
              </p>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAnalytics(!showAnalytics)}
                iconName="BarChart3"
                iconPosition="left"
              >
                Analytics
              </Button>
              <Button
                variant="default"
                onClick={() => window.location.href = '/content-upload'}
                iconName="Plus"
                iconPosition="left"
              >
                Create Content
              </Button>
            </div>
          </div>

          {/* Search and Controls */}
          <div className="flex items-center justify-between space-x-4">
            <div className="flex-1 max-w-md">
              <Input
                type="search"
                placeholder="Search content by title, tags..."
                value={filters?.search}
                onChange={(e) => handleFiltersChange({ ...filters, search: e?.target?.value })}
                className="w-full"
              />
            </div>

            <div className="flex items-center space-x-3">
              {/* View Mode Toggle */}
              <Select
                options={viewModeOptions}
                value={viewMode}
                onChange={setViewMode}
                className="w-32"
              />

              {/* Filter Toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                iconName="Filter"
                iconPosition="left"
                className="lg:hidden"
              >
                Filters
              </Button>

              {/* Select All */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSelectAll}
                iconName={selectedItems?.length === filteredContent?.length ? "CheckSquare" : "Square"}
                iconPosition="left"
              >
                {selectedItems?.length === filteredContent?.length ? 'Deselect All' : 'Select All'}
              </Button>
            </div>
          </div>

          {/* Results Summary */}
          <div className="flex items-center justify-between mt-4 text-sm text-muted-foreground">
            <span>
              {filteredContent?.length} of {content?.length} items
              {selectedItems?.length > 0 && ` • ${selectedItems?.length} selected`}
            </span>
            <div className="flex items-center space-x-4">
              <span>Sort by: {filters?.sortBy}</span>
              {(filters?.contentType !== 'all' || filters?.platform !== 'all' || filters?.status !== 'all') && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearFilters}
                  className="text-xs"
                >
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="flex">
        {/* Content Area */}
        <div className={`flex-1 p-6 ${showAnalytics ? 'mr-80' : ''}`}>
          <ContentGrid
            content={filteredContent}
            loading={loading}
            selectedItems={selectedItems}
            onSelectItem={handleSelectItem}
            onEdit={handleEdit}
            onDuplicate={handleDuplicate}
            onSchedule={handleSchedule}
            onDelete={handleDelete}
            onLoadMore={() => {}}
            hasMore={false}
          />
        </div>

        {/* Filter Panel */}
        <FilterPanel
          filters={filters}
          onFiltersChange={handleFiltersChange}
          onClearFilters={handleClearFilters}
          isCollapsed={showFilters}
          onToggleCollapse={() => setShowFilters(!showFilters)}
        />
      </div>
      {/* Bulk Actions */}
      <BulkActions
        selectedItems={selectedItems}
        onBulkEdit={handleBulkEdit}
        onBulkSchedule={handleBulkSchedule}
        onBulkDelete={handleBulkDelete}
        onBulkExport={handleBulkExport}
        onClearSelection={() => setSelectedItems([])}
      />
      {/* Analytics Panel */}
      <AnalyticsPanel
        isVisible={showAnalytics}
        onToggle={() => setShowAnalytics(!showAnalytics)}
      />
    </div>
  );
};

export default ContentLibrary;