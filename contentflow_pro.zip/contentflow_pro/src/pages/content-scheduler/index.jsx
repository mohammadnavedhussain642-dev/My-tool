import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import CalendarView from './components/CalendarView';
import UpcomingPosts from './components/UpcomingPosts';
import OptimalTimes from './components/OptimalTimes';
import SchedulingModal from './components/SchedulingModal';
import ContentLibraryPanel from './components/ContentLibraryPanel';
import AnalyticsPanel from './components/AnalyticsPanel';

const ContentScheduler = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('month');
  const [activeTab, setActiveTab] = useState('upcoming');
  const [isSchedulingModalOpen, setIsSchedulingModalOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedPost, setSelectedPost] = useState(null);
  const [modalMode, setModalMode] = useState('create');
  const [draggedContent, setDraggedContent] = useState(null);

  // Mock scheduled posts data
  const [scheduledPosts, setScheduledPosts] = useState([
    {
      id: 'post-1',
      title: 'AI Revolution in Content Creation',
      content: `The landscape of content creation is rapidly evolving with artificial intelligence at the forefront. From automated writing assistants to AI-powered video editing, creators now have unprecedented tools at their disposal.\n\nThis transformation isn't just about efficiency—it's about unlocking new creative possibilities that were previously unimaginable.`,
      platform: 'instagram',
      platforms: ['instagram', 'linkedin'],
      scheduledDate: new Date(2025, 0, 5, 17, 0)?.toISOString(),
      status: 'scheduled',
      timezone: 'EST',
      recurring: false,
      priority: 'high',
      tags: ['AI', 'Technology', 'Content Creation'],
      createdAt: new Date()?.toISOString(),
      engagement: { likes: 245, comments: 32, shares: 18 }
    },
    {
      id: 'post-2',
      title: 'Social Media Trends 2025',
      content: `Discover the top social media trends that will dominate 2025. From short-form video content to AI-generated posts, learn how to stay ahead of the curve.\n\nThis comprehensive guide covers platform-specific strategies and emerging technologies.`,
      platform: 'linkedin',
      platforms: ['linkedin', 'twitter'],
      scheduledDate: new Date(2025, 0, 6, 9, 0)?.toISOString(),
      status: 'scheduled',
      timezone: 'EST',
      recurring: true,
      recurringType: 'weekly',
      priority: 'medium',
      tags: ['Social Media', 'Trends', 'Marketing'],
      createdAt: new Date()?.toISOString()
    },
    {
      id: 'post-3',
      title: 'Building Your Personal Brand',
      content: `In this episode, we explore the fundamentals of building a strong personal brand in the digital age. Learn from industry experts about authenticity, consistency, and strategic positioning.\n\nKey takeaways include actionable steps for brand development and common pitfalls to avoid.`,
      platform: 'twitter',
      platforms: ['twitter', 'facebook'],
      scheduledDate: new Date(2025, 0, 4, 15, 30)?.toISOString(),
      status: 'published',
      timezone: 'EST',
      recurring: false,
      priority: 'medium',
      tags: ['Personal Branding', 'Career', 'Professional Development'],
      createdAt: new Date()?.toISOString(),
      engagement: { likes: 189, comments: 24, shares: 12 }
    },
    {
      id: 'post-4',
      title: 'Instagram Growth Strategies',
      content: `A comprehensive visual guide to growing your Instagram presence organically. Covers hashtag strategies, posting schedules, engagement tactics, and content planning.\n\nIncludes data-driven insights and proven techniques used by successful influencers.`,
      platform: 'instagram',
      platforms: ['instagram'],
      scheduledDate: new Date(2025, 0, 7, 11, 0)?.toISOString(),
      status: 'pending',
      timezone: 'EST',
      recurring: false,
      priority: 'high',
      tags: ['Instagram', 'Growth', 'Social Media Marketing'],
      createdAt: new Date()?.toISOString()
    },
    {
      id: 'post-5',
      title: 'Content Calendar Template',
      content: `A ready-to-use content calendar template that helps you plan, organize, and schedule your content across multiple platforms. Includes best practices and optimization tips.\n\nPerfect for content creators, marketers, and social media managers looking to streamline their workflow.`,
      platform: 'linkedin',
      platforms: ['linkedin', 'facebook'],
      scheduledDate: new Date(2025, 0, 3, 14, 0)?.toISOString(),
      status: 'failed',
      timezone: 'EST',
      recurring: false,
      priority: 'low',
      tags: ['Template', 'Planning', 'Organization'],
      createdAt: new Date()?.toISOString()
    }
  ]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleDateClick = (date) => {
    setSelectedDate(date);
    setSelectedPost(null);
    setModalMode('create');
    setIsSchedulingModalOpen(true);
  };

  const handlePostClick = (post) => {
    setSelectedPost(post);
    setSelectedDate(null);
    setModalMode('edit');
    setIsSchedulingModalOpen(true);
  };

  const handleSchedulePost = async (postData) => {
    try {
      if (modalMode === 'edit' && selectedPost) {
        // Update existing post
        setScheduledPosts(prev => 
          prev?.map(post => 
            post?.id === selectedPost?.id 
              ? { ...postData, id: selectedPost?.id, updatedAt: new Date()?.toISOString() }
              : post
          )
        );
      } else {
        // Create new post
        const newPost = {
          ...postData,
          id: `post-${Date.now()}`,
          status: 'scheduled',
          createdAt: new Date()?.toISOString(),
          updatedAt: new Date()?.toISOString()
        };
        setScheduledPosts(prev => [...prev, newPost]);
      }
    } catch (error) {
      console.error('Error scheduling post:', error);
    }
  };

  const handleEditPost = (post) => {
    setSelectedPost(post);
    setModalMode('edit');
    setIsSchedulingModalOpen(true);
  };

  const handleDeletePost = (post) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      setScheduledPosts(prev => prev?.filter(p => p?.id !== post?.id));
    }
  };

  const handleDuplicatePost = (post) => {
    const duplicatedPost = {
      ...post,
      id: `post-${Date.now()}`,
      title: `${post?.title} (Copy)`,
      scheduledDate: new Date(Date.now() + 24 * 60 * 60 * 1000)?.toISOString(), // Tomorrow
      status: 'draft',
      createdAt: new Date()?.toISOString(),
      updatedAt: new Date()?.toISOString()
    };
    setScheduledPosts(prev => [...prev, duplicatedPost]);
  };

  const handleScheduleAtOptimalTime = (platform) => {
    // Mock optimal time scheduling
    const optimalTimes = {
      instagram: new Date(Date.now() + 5 * 60 * 60 * 1000), // 5 hours from now
      linkedin: new Date(Date.now() + 17 * 60 * 60 * 1000), // Tomorrow 9 AM
      twitter: new Date(Date.now() + 17 * 60 * 60 * 1000), // Tomorrow 9 AM
      facebook: new Date(Date.now() + 3 * 60 * 60 * 1000), // 3 hours from now
      all: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      peak: new Date(Date.now() + 4 * 60 * 60 * 1000) // 4 hours from now
    };

    const optimalDate = optimalTimes?.[platform] || optimalTimes?.all;
    setSelectedDate(optimalDate);
    setSelectedPost(null);
    setModalMode('create');
    setIsSchedulingModalOpen(true);
  };

  const handleContentDragStart = (content) => {
    setDraggedContent(content);
  };

  const handleContentDrop = (content, date) => {
    if (content && date) {
      const newPost = {
        id: `post-${Date.now()}`,
        title: content?.title,
        content: content?.content,
        platform: 'instagram', // Default platform
        platforms: ['instagram'],
        scheduledDate: date?.toISOString(),
        status: 'scheduled',
        timezone: 'EST',
        recurring: false,
        priority: 'medium',
        tags: content?.tags || [],
        createdAt: new Date()?.toISOString(),
        updatedAt: new Date()?.toISOString()
      };
      setScheduledPosts(prev => [...prev, newPost]);
    }
  };

  const handleScheduleContent = (content) => {
    setSelectedPost({
      title: content?.title,
      content: content?.content,
      tags: content?.tags || []
    });
    setModalMode('create');
    setIsSchedulingModalOpen(true);
  };

  const tabItems = [
    { id: 'upcoming', label: 'Upcoming Posts', icon: 'Clock' },
    { id: 'optimal', label: 'Optimal Times', icon: 'Target' },
    { id: 'library', label: 'Content Library', icon: 'FolderOpen' },
    { id: 'analytics', label: 'Analytics', icon: 'BarChart3' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />
      </div>
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-72'
      }`}>
        <div className="p-6">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <div>
                <h1 className="text-2xl font-bold text-foreground">Content Scheduler</h1>
                <p className="text-muted-foreground">
                  Plan and automate your content publishing across multiple platforms
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="Upload"
                  iconPosition="left"
                  onClick={() => window.location.href = '/content-upload'}
                >
                  Upload Content
                </Button>
                <Button
                  iconName="Plus"
                  iconPosition="left"
                  onClick={() => {
                    setSelectedPost(null);
                    setSelectedDate(new Date());
                    setModalMode('create');
                    setIsSchedulingModalOpen(true);
                  }}
                >
                  Schedule Post
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
              <div className="bg-card rounded-lg border border-border p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="Calendar" size={20} className="text-primary" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-foreground">
                      {scheduledPosts?.filter(p => p?.status === 'scheduled')?.length}
                    </div>
                    <div className="text-sm text-muted-foreground">Scheduled</div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                    <Icon name="CheckCircle" size={20} className="text-success" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-foreground">
                      {scheduledPosts?.filter(p => p?.status === 'published')?.length}
                    </div>
                    <div className="text-sm text-muted-foreground">Published</div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                    <Icon name="Clock" size={20} className="text-warning" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-foreground">
                      {scheduledPosts?.filter(p => p?.status === 'pending')?.length}
                    </div>
                    <div className="text-sm text-muted-foreground">Pending</div>
                  </div>
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center">
                    <Icon name="XCircle" size={20} className="text-destructive" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-foreground">
                      {scheduledPosts?.filter(p => p?.status === 'failed')?.length}
                    </div>
                    <div className="text-sm text-muted-foreground">Failed</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Calendar Section */}
            <div className="xl:col-span-2">
              <CalendarView
                currentDate={currentDate}
                onDateChange={setCurrentDate}
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                scheduledPosts={scheduledPosts}
                onPostClick={handlePostClick}
                onDateClick={handleDateClick}
                onDragOver={(e) => e?.preventDefault()}
                onDrop={handleContentDrop}
              />
            </div>

            {/* Side Panel */}
            <div className="xl:col-span-1">
              {/* Tab Navigation */}
              <div className="bg-card rounded-lg border border-border mb-4">
                <div className="flex overflow-x-auto">
                  {tabItems?.map(tab => (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                        activeTab === tab?.id
                          ? 'border-primary text-primary bg-primary/5' :'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50'
                      }`}
                    >
                      <Icon name={tab?.icon} size={16} />
                      <span className="hidden sm:inline">{tab?.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Content */}
              <div className="h-[600px] overflow-hidden">
                {activeTab === 'upcoming' && (
                  <UpcomingPosts
                    posts={scheduledPosts}
                    onPostClick={handlePostClick}
                    onEditPost={handleEditPost}
                    onDeletePost={handleDeletePost}
                    onDuplicatePost={handleDuplicatePost}
                  />
                )}

                {activeTab === 'optimal' && (
                  <OptimalTimes
                    onScheduleAtOptimalTime={handleScheduleAtOptimalTime}
                  />
                )}

                {activeTab === 'library' && (
                  <ContentLibraryPanel
                    onDragStart={handleContentDragStart}
                    onScheduleContent={handleScheduleContent}
                  />
                )}

                {activeTab === 'analytics' && (
                  <AnalyticsPanel />
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
      {/* Scheduling Modal */}
      <SchedulingModal
        isOpen={isSchedulingModalOpen}
        onClose={() => {
          setIsSchedulingModalOpen(false);
          setSelectedPost(null);
          setSelectedDate(null);
        }}
        onSchedule={handleSchedulePost}
        selectedDate={selectedDate}
        selectedPost={selectedPost}
        mode={modalMode}
      />
    </div>
  );
};

export default ContentScheduler;