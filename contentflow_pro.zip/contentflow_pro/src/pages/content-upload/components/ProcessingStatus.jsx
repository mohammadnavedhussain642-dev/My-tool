import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ProcessingStatus = ({ isVisible, onClose, processingConfig }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [estimatedTimeRemaining, setEstimatedTimeRemaining] = useState(0);

  const processingSteps = [
    {
      id: 'upload',
      title: 'Uploading Files',
      description: 'Transferring files to secure servers',
      icon: 'Upload',
      duration: 30
    },
    {
      id: 'transcription',
      title: 'AI Transcription',
      description: `Converting ${processingConfig?.language || 'audio'} to text using Whisper AI`,
      icon: 'FileText',
      duration: 120
    },
    {
      id: 'analysis',
      title: 'Content Analysis',
      description: 'Analyzing content structure and key topics',
      icon: 'Brain',
      duration: 60
    },
    {
      id: 'generation',
      title: 'Content Generation',
      description: `Creating ${processingConfig?.contentTypes?.length || 1} content types`,
      icon: 'Sparkles',
      duration: 90
    },
    {
      id: 'optimization',
      title: 'Platform Optimization',
      description: `Optimizing for ${processingConfig?.platforms?.length || 1} platforms`,
      icon: 'Target',
      duration: 45
    },
    {
      id: 'completion',
      title: 'Processing Complete',
      description: 'Content ready for review and editing',
      icon: 'CheckCircle',
      duration: 5
    }
  ];

  useEffect(() => {
    if (!isVisible) return;

    const totalDuration = processingSteps?.reduce((sum, step) => sum + step?.duration, 0);
    let elapsedTime = 0;

    const interval = setInterval(() => {
      elapsedTime += 1;
      const newProgress = Math.min((elapsedTime / totalDuration) * 100, 100);
      setProgress(newProgress);
      setEstimatedTimeRemaining(Math.max(totalDuration - elapsedTime, 0));

      // Update current step based on progress
      let cumulativeDuration = 0;
      for (let i = 0; i < processingSteps?.length; i++) {
        cumulativeDuration += processingSteps?.[i]?.duration;
        if (elapsedTime <= cumulativeDuration) {
          setCurrentStep(i);
          break;
        }
      }

      // Complete processing
      if (elapsedTime >= totalDuration) {
        setCurrentStep(processingSteps?.length - 1);
        clearInterval(interval);
        setTimeout(() => {
          onClose();
          // Navigate to content editor
          window.location.href = '/content-editor';
        }, 2000);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isVisible, processingConfig, onClose]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl p-8 max-w-md w-full shadow-prominent">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto bg-primary/20 rounded-full flex items-center justify-center mb-4">
            <Icon 
              name={processingSteps?.[currentStep]?.icon || 'Loader2'} 
              size={32} 
              className="text-primary animate-pulse" 
            />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Processing Your Content
          </h2>
          <p className="text-muted-foreground">
            AI is working on your files. This may take a few minutes.
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-foreground">
              {Math.round(progress)}% Complete
            </span>
            <span className="text-sm text-muted-foreground">
              {formatTime(estimatedTimeRemaining)} remaining
            </span>
          </div>
          <div className="w-full bg-border rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-1000 ease-out"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        {/* Current Step */}
        <div className="bg-muted/50 rounded-lg p-4 mb-6">
          <div className="flex items-center space-x-3">
            <Icon 
              name={processingSteps?.[currentStep]?.icon || 'Loader2'} 
              size={20} 
              className="text-primary animate-spin" 
            />
            <div>
              <h3 className="text-sm font-medium text-foreground">
                {processingSteps?.[currentStep]?.title}
              </h3>
              <p className="text-xs text-muted-foreground">
                {processingSteps?.[currentStep]?.description}
              </p>
            </div>
          </div>
        </div>

        {/* Processing Steps */}
        <div className="space-y-3 mb-6">
          {processingSteps?.map((step, index) => (
            <div key={step?.id} className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                index < currentStep 
                  ? 'bg-success text-white' 
                  : index === currentStep 
                  ? 'bg-primary text-white' :'bg-muted text-muted-foreground'
              }`}>
                {index < currentStep ? (
                  <Icon name="Check" size={14} />
                ) : index === currentStep ? (
                  <Icon name="Loader2" size={14} className="animate-spin" />
                ) : (
                  <span className="text-xs">{index + 1}</span>
                )}
              </div>
              <div className="flex-1">
                <div className={`text-sm ${
                  index <= currentStep ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {step?.title}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Processing Configuration Summary */}
        <div className="bg-muted/30 rounded-lg p-3 mb-6 text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-muted-foreground">Language:</span>
              <span className="ml-1 text-foreground capitalize">
                {processingConfig?.language || 'English'}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Content Types:</span>
              <span className="ml-1 text-foreground">
                {processingConfig?.contentTypes?.length || 1}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Platforms:</span>
              <span className="ml-1 text-foreground">
                {processingConfig?.platforms?.length || 1}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Files:</span>
              <span className="ml-1 text-foreground">
                {processingConfig?.fileCount || 1}
              </span>
            </div>
          </div>
        </div>

        {/* Cancel Button */}
        <Button
          variant="outline"
          fullWidth
          onClick={onClose}
          iconName="X"
          iconPosition="left"
          disabled={currentStep >= processingSteps?.length - 1}
        >
          Cancel Processing
        </Button>

        {/* Success Message */}
        {currentStep >= processingSteps?.length - 1 && (
          <div className="mt-4 text-center">
            <Icon name="CheckCircle" size={24} className="text-success mx-auto mb-2" />
            <p className="text-sm text-success font-medium">
              Processing completed successfully!
            </p>
            <p className="text-xs text-muted-foreground">
              Redirecting to content editor...
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProcessingStatus;