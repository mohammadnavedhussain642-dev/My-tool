import React, { useState, useEffect } from 'react';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import FileUploadZone from './components/FileUploadZone';
import UploadedFilesList from './components/UploadedFilesList';
import ProcessingOptions from './components/ProcessingOptions';
import UploadHistory from './components/UploadHistory';
import ProcessingStatus from './components/ProcessingStatus';

const ContentUpload = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showProcessingStatus, setShowProcessingStatus] = useState(false);
  const [processingConfig, setProcessingConfig] = useState(null);
  const [activeTab, setActiveTab] = useState('upload');

  // Simulate file upload progress
  const simulateUpload = (files) => {
    setIsUploading(true);
    setUploadProgress(0);

    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          
          // Add files to uploaded list with completed status
          const processedFiles = files?.map((file, index) => ({
            ...file,
            id: Date.now() + index,
            status: 'completed',
            progress: 100,
            thumbnail: file?.type?.startsWith('video/') 
              ? 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=100&h=100&fit=crop' 
              : null,
            duration: Math.floor(Math.random() * 3600) + 300 // Random duration between 5-65 minutes
          }));
          
          setUploadedFiles(prev => [...prev, ...processedFiles]);
          return 100;
        }
        return prev + Math.random() * 15 + 5;
      });
    }, 500);
  };

  const handleFileSelect = (files) => {
    simulateUpload(files);
  };

  const handleRemoveFile = (index) => {
    setUploadedFiles(prev => prev?.filter((_, i) => i !== index));
  };

  const handleRetryUpload = (index) => {
    setUploadedFiles(prev => 
      prev?.map((file, i) => 
        i === index 
          ? { ...file, status: 'uploading', progress: 0, error: null }
          : file
      )
    );
    
    // Simulate retry upload
    setTimeout(() => {
      setUploadedFiles(prev => 
        prev?.map((file, i) => 
          i === index 
            ? { ...file, status: 'completed', progress: 100 }
            : file
        )
      );
    }, 3000);
  };

  const handleStartProcessing = (config) => {
    setProcessingConfig({
      ...config,
      fileCount: uploadedFiles?.length
    });
    setIsProcessing(true);
    setShowProcessingStatus(true);
  };

  const handleCloseProcessingStatus = () => {
    setShowProcessingStatus(false);
    setIsProcessing(false);
  };

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const tabOptions = [
    { id: 'upload', label: 'Upload Files', icon: 'Upload' },
    { id: 'history', label: 'Upload History', icon: 'History' }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />
      </div>
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-72'
      }`}>
        <div className="p-4 lg:p-8">
          {/* Page Header */}
          <div className="mb-8">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                <Icon name="Upload" size={24} className="text-primary" />
              </div>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-foreground">Content Upload</h1>
                <p className="text-muted-foreground">
                  Upload video and audio files for AI-powered transcription and content generation
                </p>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Icon name="FileUp" size={20} className="text-primary" />
                  <div>
                    <div className="text-lg font-semibold text-foreground">{uploadedFiles?.length}</div>
                    <div className="text-xs text-muted-foreground">Files Ready</div>
                  </div>
                </div>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Icon name="Clock" size={20} className="text-warning" />
                  <div>
                    <div className="text-lg font-semibold text-foreground">
                      {uploadedFiles?.filter(f => f?.status === 'processing')?.length}
                    </div>
                    <div className="text-xs text-muted-foreground">Processing</div>
                  </div>
                </div>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Icon name="CheckCircle" size={20} className="text-success" />
                  <div>
                    <div className="text-lg font-semibold text-foreground">
                      {uploadedFiles?.filter(f => f?.status === 'completed')?.length}
                    </div>
                    <div className="text-xs text-muted-foreground">Completed</div>
                  </div>
                </div>
              </div>
              <div className="bg-card border border-border rounded-lg p-4">
                <div className="flex items-center space-x-2">
                  <Icon name="HardDrive" size={20} className="text-secondary" />
                  <div>
                    <div className="text-lg font-semibold text-foreground">2.4 GB</div>
                    <div className="text-xs text-muted-foreground">Storage Used</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-1 mb-6 bg-muted rounded-lg p-1">
            {tabOptions?.map((tab) => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`flex items-center space-x-2 flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                  activeTab === tab?.id
                    ? 'bg-background text-foreground shadow-sm'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                <span>{tab?.label}</span>
              </button>
            ))}
          </div>

          {/* Content Based on Active Tab */}
          {activeTab === 'upload' ? (
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              {/* Left Column - Upload Zone and Files */}
              <div className="xl:col-span-2 space-y-8">
                {/* File Upload Zone */}
                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                      <Icon name="CloudUpload" size={20} className="text-primary" />
                    </div>
                    <div>
                      <h2 className="text-lg font-semibold text-foreground">Upload Files</h2>
                      <p className="text-sm text-muted-foreground">
                        Drag and drop or browse to upload video and audio files
                      </p>
                    </div>
                  </div>
                  
                  <FileUploadZone
                    onFileSelect={handleFileSelect}
                    isUploading={isUploading}
                    uploadProgress={uploadProgress}
                  />
                </div>

                {/* Uploaded Files List */}
                {uploadedFiles?.length > 0 && (
                  <div className="bg-card border border-border rounded-xl p-6">
                    <UploadedFilesList
                      files={uploadedFiles}
                      onRemoveFile={handleRemoveFile}
                      onRetryUpload={handleRetryUpload}
                    />
                  </div>
                )}

                {/* Batch Actions */}
                {uploadedFiles?.length > 1 && (
                  <div className="bg-card border border-border rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Icon name="Package" size={20} className="text-accent" />
                        <div>
                          <h3 className="text-sm font-medium text-foreground">Batch Actions</h3>
                          <p className="text-xs text-muted-foreground">
                            Process multiple files together
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="Trash2"
                          onClick={() => setUploadedFiles([])}
                        >
                          Clear All
                        </Button>
                        <Button
                          variant="default"
                          size="sm"
                          iconName="Play"
                          disabled={uploadedFiles?.filter(f => f?.status === 'completed')?.length === 0}
                        >
                          Process All
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column - Processing Options */}
              <div className="space-y-8">
                <ProcessingOptions
                  onStartProcessing={handleStartProcessing}
                  hasFiles={uploadedFiles?.filter(f => f?.status === 'completed')?.length > 0}
                  isProcessing={isProcessing}
                />

                {/* Quick Tips */}
                <div className="bg-card border border-border rounded-xl p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                      <Icon name="Lightbulb" size={20} className="text-accent" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">Quick Tips</h3>
                  </div>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Upload high-quality audio for better transcription accuracy</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Choose the correct language for optimal AI processing</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Select multiple content types to maximize your content output</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Icon name="Check" size={16} className="text-success mt-0.5 flex-shrink-0" />
                      <span>Processing time varies based on file length and selected options</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Upload History Tab */
            (<UploadHistory />)
          )}
        </div>
      </main>
      {/* Processing Status Modal */}
      <ProcessingStatus
        isVisible={showProcessingStatus}
        onClose={handleCloseProcessingStatus}
        processingConfig={processingConfig}
      />
    </div>
  );
};

export default ContentUpload;