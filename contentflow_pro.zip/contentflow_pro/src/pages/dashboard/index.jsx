import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import FeatureCard from './components/FeatureCard';
import ActivityFeed from './components/ActivityFeed';
import UsageStats from './components/UsageStats';
import QuickActions from './components/QuickActions';
import UploadZone from './components/UploadZone';
import ProcessingStatus from './components/ProcessingStatus';
import Icon from '../../components/AppIcon';

const Dashboard = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const featureCards = [
    {
      title: "Video Upload & Processing",
      description: "Upload videos and convert them into multiple content formats with AI-powered transcription and generation.",
      icon: "Video",
      iconColor: "var(--color-primary)",
      buttonText: "Upload Video",
      onClick: () => navigate('/content-upload'),
      isNew: false
    },
    {
      title: "Audio Content Processing",
      description: "Transform podcasts and audio files into blogs, social posts, and engaging written content.",
      icon: "Headphones",
      iconColor: "var(--color-secondary)",
      buttonText: "Upload Audio",
      onClick: () => navigate('/content-upload'),
      isNew: false
    },
    {
      title: "Content Editor",
      description: "Refine and customize your AI-generated content with our powerful editing tools and templates.",
      icon: "Edit3",
      iconColor: "var(--color-success)",
      buttonText: "Open Editor",
      onClick: () => navigate('/content-editor'),
      isNew: false
    },
    {
      title: "Content Library",
      description: "Organize, manage, and access all your generated content in one centralized location.",
      icon: "FolderOpen",
      iconColor: "var(--color-accent)",
      buttonText: "View Library",
      onClick: () => navigate('/content-library'),
      isNew: false
    },
    {
      title: "Content Scheduler",
      description: "Schedule and automate your content publishing across multiple social media platforms.",
      icon: "Calendar",
      iconColor: "var(--color-warning)",
      buttonText: "Schedule Content",
      onClick: () => navigate('/content-scheduler'),
      isNew: true
    },
    {
      title: "Analytics Dashboard",
      description: "Track performance metrics and insights for your content across all platforms.",
      icon: "BarChart3",
      iconColor: "var(--color-primary)",
      buttonText: "View Analytics",
      onClick: () => console.log('Analytics coming soon'),
      disabled: true
    }
  ];

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleQuickAction = (actionId) => {
    switch (actionId) {
      case 'blog-generator': navigate('/content-editor?type=blog');
        break;
      case 'social-posts': navigate('/content-editor?type=social');
        break;
      case 'twitter-thread': navigate('/content-editor?type=thread');
        break;
      case 'linkedin-post': navigate('/content-editor?type=linkedin');
        break;
      default:
        console.log('Action not implemented:', actionId);
    }
  };

  const handleFileUpload = (files) => {
    console.log('Files uploaded:', files);
    // Navigate to upload page with files
    navigate('/content-upload', { state: { files } });
  };

  const formatTime = (date) => {
    return date?.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date?.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />
      </div>
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-72'
      }`}>
        <div className="p-6 max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Welcome back, John! 👋
                </h1>
                <p className="text-muted-foreground">
                  {formatDate(currentTime)} • {formatTime(currentTime)}
                </p>
              </div>
              
              <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                <div className="flex items-center space-x-2 px-3 py-2 bg-success/10 rounded-lg">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-success">All Systems Operational</span>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg p-6 border border-border">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground mb-2">
                    Ready to create amazing content?
                  </h2>
                  <p className="text-muted-foreground mb-4">
                    Transform your videos and audio into engaging content across all platforms
                  </p>
                </div>
                <div className="hidden sm:block">
                  <Icon name="Sparkles" size={48} className="text-primary opacity-50" />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Upload Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div className="lg:col-span-2">
              <UploadZone onFileUpload={handleFileUpload} />
            </div>
            <div>
              <QuickActions onActionClick={handleQuickAction} />
            </div>
          </div>

          {/* Feature Cards Grid */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold text-foreground">Content Tools</h2>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Icon name="Grid3X3" size={16} />
                <span>6 tools available</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featureCards?.map((card, index) => (
                <FeatureCard
                  key={index}
                  title={card?.title}
                  description={card?.description}
                  icon={card?.icon}
                  iconColor={card?.iconColor}
                  buttonText={card?.buttonText}
                  onClick={card?.onClick}
                  isNew={card?.isNew}
                  disabled={card?.disabled}
                />
              ))}
            </div>
          </div>

          {/* Dashboard Widgets */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Activity and Processing */}
            <div className="lg:col-span-2 space-y-6">
              <ActivityFeed />
              <ProcessingStatus />
            </div>
            
            {/* Right Column - Stats */}
            <div>
              <UsageStats />
            </div>
          </div>

          {/* Footer Info */}
          <div className="mt-12 pt-8 border-t border-border">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between text-sm text-muted-foreground">
              <div className="flex items-center space-x-4 mb-4 sm:mb-0">
                <span>© {new Date()?.getFullYear()} ContentFlow Pro</span>
                <span>•</span>
                <span>Version 2.1.0</span>
              </div>
              <div className="flex items-center space-x-4">
                <button className="hover:text-foreground transition-colors">Help Center</button>
                <span>•</span>
                <button className="hover:text-foreground transition-colors">API Status</button>
                <span>•</span>
                <button className="hover:text-foreground transition-colors">Feedback</button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;