import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import MetricsChart from './components/MetricsChart';
import OptimizationPanel from './components/OptimizationPanel';
import SystemHealth from './components/SystemHealth';
import PerformanceReports from './components/PerformanceReports';

const PerformanceAnalytics = () => {
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [timeRange, setTimeRange] = useState('7d');
  const [refreshInterval, setRefreshInterval] = useState(30000); // 30 seconds

  const handleSidebarToggle = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const performanceMetrics = [
    {
      title: 'Processing Speed',
      value: '2.3s',
      change: '+12%',
      trend: 'up',
      icon: 'Zap',
      color: 'text-success'
    },
    {
      title: 'Success Rate',
      value: '98.7%',
      change: '+5%',
      trend: 'up',
      icon: 'CheckCircle',
      color: 'text-success'
    },
    {
      title: 'API Response Time',
      value: '450ms',
      change: '-8%',
      trend: 'down',
      icon: 'Clock',
      color: 'text-warning'
    },
    {
      title: 'Storage Usage',
      value: '2.4GB',
      change: '+23%',
      trend: 'up',
      icon: 'HardDrive',
      color: 'text-primary'
    }
  ];

  const optimizationRecommendations = [
    {
      title: 'Enable CDN Caching',
      description: 'Reduce loading times by 40% with CloudFlare CDN implementation',
      impact: 'High',
      effort: 'Medium',
      priority: 1
    },
    {
      title: 'Database Query Optimization',
      description: 'Optimize slow queries identified in processing pipeline',
      impact: 'High',
      effort: 'High',
      priority: 2
    },
    {
      title: 'Implement Lazy Loading',
      description: 'Improve frontend performance with component lazy loading',
      impact: 'Medium',
      effort: 'Low',
      priority: 3
    },
    {
      title: 'Add Redis Caching',
      description: 'Cache frequently accessed data to reduce database load',
      impact: 'High',
      effort: 'Medium',
      priority: 4
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <Header 
        onMenuToggle={handleMobileMenuToggle}
        isMenuOpen={isMobileMenuOpen}
      />
      {/* Sidebar */}
      <div className="hidden lg:block">
        <Sidebar 
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={handleSidebarToggle}
        />
      </div>
      {/* Main Content */}
      <main className={`pt-16 transition-all duration-300 ${
        isSidebarCollapsed ? 'lg:ml-16' : 'lg:ml-72'
      }`}>
        <div className="p-6 max-w-7xl mx-auto">
          {/* Header Section */}
          <div className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Performance Analytics
                </h1>
                <p className="text-muted-foreground">
                  Monitor system performance and optimization opportunities
                </p>
              </div>
              
              <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                <select 
                  value={timeRange} 
                  onChange={(e) => setTimeRange(e?.target?.value)}
                  className="px-3 py-2 bg-card border border-border rounded-md text-sm"
                >
                  <option value="1d">Last 24 Hours</option>
                  <option value="7d">Last 7 Days</option>
                  <option value="30d">Last 30 Days</option>
                  <option value="90d">Last 90 Days</option>
                </select>
                <button 
                  onClick={() => window.location?.reload()}
                  className="flex items-center space-x-2 px-3 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
                >
                  <Icon name="RefreshCw" size={16} />
                  <span>Refresh</span>
                </button>
              </div>
            </div>
          </div>

          {/* Performance Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {performanceMetrics?.map((metric, index) => (
              <div key={index} className="bg-card border border-border rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-10 h-10 rounded-lg ${metric?.color === 'text-success' ? 'bg-success/10' : metric?.color === 'text-warning' ? 'bg-warning/10' : 'bg-primary/10'} flex items-center justify-center`}>
                    <Icon name={metric?.icon} size={20} className={metric?.color} />
                  </div>
                  <div className={`flex items-center space-x-1 text-sm ${metric?.trend === 'up' ? 'text-success' : 'text-destructive'}`}>
                    <Icon name={metric?.trend === 'up' ? 'TrendingUp' : 'TrendingDown'} size={16} />
                    <span>{metric?.change}</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-foreground mb-1">{metric?.value}</h3>
                  <p className="text-sm text-muted-foreground">{metric?.title}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Charts and Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="lg:col-span-1">
              <MetricsChart timeRange={timeRange} />
            </div>
            <div className="lg:col-span-1">
              <SystemHealth />
            </div>
          </div>

          {/* Optimization Recommendations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="lg:col-span-1">
              <OptimizationPanel recommendations={optimizationRecommendations} />
            </div>
            <div className="lg:col-span-1">
              <PerformanceReports />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PerformanceAnalytics;